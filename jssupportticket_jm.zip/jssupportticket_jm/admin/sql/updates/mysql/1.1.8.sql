UPDATE `#__js_ticket_config` SET `configvalue`='118' WHERE `configname`='version';
