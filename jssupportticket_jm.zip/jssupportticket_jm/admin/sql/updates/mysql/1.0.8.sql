UPDATE `#__js_ticket_config` SET `configvalue`='108' WHERE `configname`='version';
