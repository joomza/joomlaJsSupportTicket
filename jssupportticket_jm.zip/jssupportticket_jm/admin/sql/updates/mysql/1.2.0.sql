UPDATE `#__js_ticket_config` SET `configvalue`='120' WHERE `configname`='version';
