UPDATE `#__js_ticket_config` SET `configvalue`='116' WHERE `configname`='version';
