UPDATE `#__js_ticket_config` SET `configvalue`='123' WHERE `configname`='version';

