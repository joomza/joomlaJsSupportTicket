UPDATE `#__js_ticket_config` SET `configvalue`='122' WHERE `configname`='version';

