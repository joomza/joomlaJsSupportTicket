INSERT INTO `#__js_ticket_config` (`configname`, `configvalue`, `configfor`) VALUES ('cplink_latesttickets_staff', '1', 'cplink');
INSERT INTO `#__js_ticket_config` (`configname`, `configvalue`, `configfor`) VALUES ('cplink_totalcount_staff', '1', 'cplink');
INSERT INTO `#__js_ticket_config` (`configname`, `configvalue`, `configfor`) VALUES ('cplink_ticketstats_staff', '1', 'cplink');
INSERT INTO `#__js_ticket_config` (`configname`, `configvalue`, `configfor`) VALUES ('show_header', '1', 'default');

UPDATE `#__js_ticket_config` SET `configvalue`='115' WHERE `configname`='version';
