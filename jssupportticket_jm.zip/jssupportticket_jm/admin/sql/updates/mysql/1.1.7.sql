UPDATE `#__js_ticket_config` SET `configvalue`='117' WHERE `configname`='version';
