UPDATE `#__js_ticket_config` SET `configvalue`='109' WHERE `configname`='version';
