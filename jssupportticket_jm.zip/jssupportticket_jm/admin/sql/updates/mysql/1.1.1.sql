UPDATE `#__js_ticket_config` SET `configvalue`='111' WHERE `configname`='version';
